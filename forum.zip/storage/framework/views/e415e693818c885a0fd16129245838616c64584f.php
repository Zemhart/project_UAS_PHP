<!DOCTYPE html>
<html>
<head>
	<title>Hello</title>
</head>
<body>
	<h1>Hello, <?php echo e($name); ?> </h1>
</body>
</html>
