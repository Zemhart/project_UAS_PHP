<?php $__env->startSection('sidebar'); ?>
<script>
    function newgroup()
    {
        var idgroup = $("#idgroup").val();
        var groupname = $("#groupname").val();
        var userid = $("#userid").val();
        var tok = $("#_token").val();

        var param = {
            "idgroup": idgroup,
            "groupname": groupname,
            "userid": userid,
            "_token": tok
        };

        $.ajax({
            method: "POST",
            url: '/tasks/public/new',
            data: param,
            success:function(data)
            {
                alert("Success");
                location.reload();
            },
            error:function()
            {
                alert("failed create group");
            }
        });
    }
</script>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-info">
            <div class="panel-heading">Your Groups</div>
            <div class="panel-body">
                <ul class="list-group">
                    <?php if(count($group) > 0): ?>
                	<?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<li class="list-group-item"><a href="<?php echo e(url('groups', $g->groupId)); ?>"><?php echo e($g->groupName); ?></a></li>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        You don't have any group
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Create Group</div>
            <div class="panel-body">
                <div class="form-group">
                    <label for="idgroup">Group id:</label>
                    <input type="text" name="idgroup" id="idgroup" placeholder="Group id...">
                </div>
                <div class="form-group">
                    <label for="groupname">Group name:</label>
                    <input type="text" name="groupname" id="groupname" placeholder="Group name...">
                </div>
                <button type="create" class="btn btn-default" onclick="newgroup()">Create New Group</button>
                <input type="hidden" name="_token" id="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="userid" id="userid" value="<?php echo e(Auth::user()->id); ?>">                
            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>