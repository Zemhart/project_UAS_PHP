<?php $__env->startSection('sidebar'); ?>

<script>
    function change()
    {
        var idgroup = $("#groupid").val();
        var goal = $("#mainpost").val();
        var param = {
            "idgroup" : idgroup,
            "goal" : goal,
            "_token" : $("#_token").val()
        };
        $.ajax({
            method: "POST",
            url: "/tasks/public/change",
            data: param,
            success: function(data)
            {
                alert("Success");
                $("#goal").text(goal);
            },
            error: function()
            {
                alert("failed");
            }
        });
    }
    function done(task) 
    {
        var param = {
            "taskid" : task.taskId,
            "_token" : $("#_token").val()
        };

        $.ajax({
            method: "POST",
            url: "/tasks/public/done",
            data: param,
            success: function()
            {
                alert("Success");
                location.reload();
            },
            error: function()
            {
                alert("failed");
            }
        });
    }

    function setTask() 
    {   
        var taskname = $("#taskName").val();
        var taskcontent = $("#taskcontent").val();
        var idgroup = $("#groupid").val();
        var tok = $('#_token').val();
        var memberid = $("#member").find(":selected").val();
        
        var param = {
            "name" : taskname,
            "detail" : taskcontent,
            "idgroup" : idgroup,
            "member" : memberid,
            "_token" : tok
        };
        $.ajax({
            method: "POST",
            url: '/tasks/public/setTask',
            data: param,
            success:function(data)
            {
                alert(data.msg);
                $("#stat").text('');
                location.reload();
            },
            error:function()
            {
                alert("failed adding task");
            }
        });
    }
</script>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
    <div class="page-header">
        <h2><?php echo e($group->groupName); ?></h2>
    </div>
    </div>
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-primary">
            <div class="panel-heading"><strong>GOAL</strong></div>
                <div class="panel-body">
                    <h3 id="goal" style="font-family:'Lucida Console', Monaco, monospace"><?php echo e($group->mainPost); ?></h3>
                    <?php if(Auth::user()->id == $group->groupAdmin): ?>
                        <div class="form-group">
                                <label for="mainpost">Change goal:</label>
                                <textarea name="mainpost" class="form-control" id="mainpost"></textarea>
                        </div>
                        <button type="change" class="btn btn-default" onclick="change()">Change</button>
                        
                    <?php endif; ?>
                </div>
        </div>
    </div>
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-info">
            <div class="panel-heading"><strong>MEMBER</strong></div>
                <div class="panel-body">
                    <ul class="list-group">
                    <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <p class="list-group-item-heading"><?php echo e($m->name); ?>

                        <?php if($m->userId == $group->groupAdmin): ?>
                            (Admin)
                        <?php endif; ?>
                        </p>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
        </div>
    </div>
    <?php if(count($authmember) > 0): ?>
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-info">
            <div class="panel-heading"><strong>PENDING TASK</strong></div>
                <div class="panel-body">
                    <ul id="taskList" class="list-group">
                    <?php if($task->count() === 0): ?>
                        <p id="stat">You don't have any task<p>
                    <?php else: ?>
                    <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <h4 class="list-group-item-heading"><?php echo e($t->taskName); ?></h4>
                        <p class="list-group-item-text"><?php echo e($t->taskDetail); ?></p>
                        <p>PIC: <?php echo e($t->name); ?></p>
                        <?php if(Auth::user()->id == $t->userid): ?>
                        <button type="submit" class="btn btn-success" onclick="done(<?php echo e($t); ?>)">Done</button>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </ul>
                </div>
        </div>
    </div>
    <?php if(Auth::user()->id == $group->groupAdmin): ?>
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Create New Task</div>
            <div class="panel-body">
                <div id="msg"></div>
                <!-- <form action="<?php echo e(url('groupTask')); ?>" method="POST"> -->
                <input type="text" name="name" id="taskName" placeholder="Task name">
                <br><br>
                <textarea name="content" id="taskcontent" placeholder="Describe task..."></textarea>
                <br>
                Select Member:<br>
                <select id="member">
                    <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($m->userId); ?>"><?php echo e($m->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                </select>
                <br><br>                
                <input type="button" name="submit" value="Add Task" onclick="setTask()">
                <input type="hidden" name="groupid" id="groupid" value="<?php echo e($group->idGroup); ?>">
                <input type="hidden" name="_token" id="_token" value="<?php echo e(csrf_token()); ?>">
                <!-- </form> -->
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php else: ?>
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-body">
            <form action="<?php echo e(url('join')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <input type="submit" value="Join">
                <input type="hidden" name="userid" value="<?php echo e(Auth::user()->id); ?>">
                <input type="hidden" name="groupid" value="<?php echo e($group->idGroup); ?>">    
            </form>
                
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>