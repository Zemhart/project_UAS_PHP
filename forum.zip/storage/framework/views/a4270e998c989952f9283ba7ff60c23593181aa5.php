<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="<?php echo e(route('group')); ?>">Groups<span class="sr-only">(current)</span></a></li>
            <li><a href="#">Message</a></li>
            <li><a href="#">Another</a></li>
          </ul>
        </div>
        <?php echo $__env->yieldContent('sidebar'); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>