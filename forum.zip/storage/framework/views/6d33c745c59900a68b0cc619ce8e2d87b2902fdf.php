<?php $__env->startSection('content'); ?>
<div class="panel-body">
    <?php echo $__env->make('errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <form action="<?php echo e(url('task')); ?>" method="post" class="form-horizontal">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="task" class="col-sm-3 control-label">Task</label>
            <div class="col-sm-6">
                <input type="text" name="name" id="task-name" placeholder="Task name">
            </div> 
        </div>
        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-6">
                <button type="submit" class="btn btn-default">
                    <i class="fa fa-plus"></i> Add Task
                </button>
            </div>
        </div>
    </form>
</div>
<?php if(count($tasks) > 0): ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            Current Tasks
        </div>
        <div class="panel-body">
            <table class="table table-striped task-table">
                <thead>
                    <th>Task</th>
                    <th>&nbsp;</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="table-text">
                                <div><?php echo e($task->name); ?></div>
                            </td>
                            <td>
                                <form action="<?php echo e(url('task', $task->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button>Delete Task</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>    
    </div>
<?php endif; ?>
<!-- <div class="panel-body">
    <ul>

    </ul>
</div>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Create New Task</div>
            <div class="panel-body">
                <form action="<?php echo e(url('task')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="text" name="name" placeholder="Task name">
                    <input type="submit" name="submit" value="Add Task">
                </form>
            </div>
        </div>
    </div>
</div>    
<strong>Current group tasks:</strong>
<ul>
</ul>
<form action="<?php echo e(url('task')); ?>" method="post">
	<?php echo e(csrf_field()); ?>

	<input type="text" name="username" placeholder="Your user name..."><br>
	<input type="password" name="password" placeholder="Your password...">
	<input type="submit" name="login" value="Login">
</form> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>