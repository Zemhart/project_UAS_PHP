<?php $__env->startSection('sidebar'); ?>
<div class="col-md-8 col-md-offset-2">
    <div class="page-header">
        <h2>Welcome</h2>
    </div>
</div>
<div class="col-md-8 col-md-offset-2">
    <div class="panel panel-info">
        <div class="panel-heading">Current Tasks</div>
        <div class="panel-body">
            <?php if(count($tasks) > 0): ?>
            <table class="table table-striped task-table">
                <tbody>
                    <thead>
                        <th>Task</th>
                        <th>Detail</th>
                        <th>Group</th>
                    </thead>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="table-text">
                            <?php echo e($task->taskName); ?>

                        </td>
                        <td>
                            <?php echo e($task->taskDetail); ?>

                        </td>
                        <td>
                            <?php echo e($task->groupName); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php else: ?>
            <p>You don't have any task</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>        
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>